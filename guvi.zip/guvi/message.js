function myFunction() {
var fname = document.getElementById("fname").value;
var lname = document.getElementById("lname").value;
var email = document.getElementById("email").value;

var password = document.getElementById("password").value;
if (fname == '' || lname == '' || email =='' || password =='') {
alert("Insertion Failed Some Fields are Blank....!!");
} else {
// Returns successful data submission message when the entered information is stored in database.
$.post("Registration.php", {
fname: fname,
lname: lname,
email: email,
password: password,
}, function(data) {
       var ask = window.confirm("Are you sure you want to submit?");

    if (ask) {
               window.alert(data);


        window.location.href = "call.html";

    }$('#form')[0].reset(); // To reset form fields
});
}
 return false;
}
