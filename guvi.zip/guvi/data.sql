-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 27, 2018 at 03:07 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

DROP TABLE IF EXISTS `details`;
CREATE TABLE IF NOT EXISTS `details` (
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`username`, `email`, `contact`, `address`) VALUES
('lk', 'lk@lk', '876', 'vfxcc'),
('resh', 'resh@banu', '2677', 'hbhds'),
('sd', 'sd@sd', '267773', 'ghdhdh'),
('sd', 'sd@sd', '267773', 'ghdhdh'),
('kl', 'kl@kl', '567', 'dfgg'),
('mn', 'mn@mn', '667', 'mnmn'),
('bv', 'bv@bv', '765899', 'gghbn'),
('ilaimaran', 'ilai@maran', '4455577', 'fghjbnvvvcfg'),
('akbarresh', 'akbar@resh', '7855551111', 'fgghjbvdcsds'),
('reshma', 'reshma@ga', '87789889', 'velachery'),
('jaan', 'jaan@resh', '76887989', 'fcgghhghg'),
('hihhiuh', 'hihjhj', '0999', 'hbhhhj'),
('', 'hihjhj', '0999', 'hbhhhj'),
('hihhiuh', 'hihjhj', '0999', 'hbhhhj'),
('hihhiuh', 'hihjhj', '0999', 'hbhhhj'),
('hihhiuh', 'hihjhj', '0999', 'hbhhhj'),
('arun', 'arun@prakasg', '32345456', 'fggygh');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`) VALUES
(34, 'allah', 'banu', 'allah@banu', 'allah'),
(54, 'arun', 'prakash', 'hgjhujh@oppopo', 'jbhjhj'),
(55, 'arun', 'prakash', 'arun@prakasg', 'mnbvc'),
(53, 'sameer', 'sha', 'hhjjhjk@qewe', 'ooiiooi'),
(52, 'hi', 'gyyug', 'vgjgg@waesrde', 'gtfgtugyu'),
(51, 'mnanjkfjnk', 'huiuiijlijiou', 'uruiuiui@hijihjkkj', 'hbjhh'),
(50, 'mnanjkfjnk', 'huiuiijlijiou', 'uruiuiui@hijihjkkj', 'hbjhh'),
(49, 'mnanjkfjnk', 'huiuiijlijiou', 'uruiuiui@hijihjkkj', 'uuuiui'),
(48, 'mnanjkfjnk', 'huiuiijlijiou', 'uruiuiui@hijihjkkj', 'uuuiui'),
(47, 'jaan', 'akbar', 'jaan@resh', 'banu'),
(46, 'jaan', 'akbar', 'jaan@resh', 'banu'),
(44, 'akbarjaan', 'hussain', 'akbarjaan@hussain', 'reshma'),
(45, 'akbarjaan', 'hussain', 'akbarjaan@hussain', 'reshma');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
