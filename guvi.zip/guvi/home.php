<?php

require_once('dbconnect.php');


$email = $_POST['email'];


$stmt = "select * from details where email ='$email'";
$run =$connect->prepare($stmt);
$run->execute();
$fetch = array();
while($row=$run->fetch(PDO::FETCH_ASSOC)){
$fetch['details'] =$row;
}
echo json_encode($fetch);

?>





   
