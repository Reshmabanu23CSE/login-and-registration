


<?php
	require 'config.php';
	if($_POST)
	{
			
		

		$collegename = $_POST['collegename'];
		
		$username = $_POST['username'];
	    $password = $_POST['password'];
			
		$rollno = $_POST['rollno'];
		

	    $city = $_POST['city'];

	    $department = $_POST['department'];


		
		try
		{	
		
			$stmt = $connect->prepare("SELECT * FROM tbl_form WHERE username=:username");
			$stmt->execute(array(":username"=>$username));
			$count = $stmt->rowCount();
			
			if($count==0){
				
			$stmt = $connect->prepare("INSERT INTO tbl_form(collegename,username,password,rollno,city,department) VALUES(:collegename, :username, :password, :rollno, :city, :department)");
			$stmt->bindParam(":collegename",$collegename);
		
			$stmt->bindParam(":username",$username);
	
			$stmt->bindParam(":password",$password);

	        $stmt->bindParam(":rollno",$rollno);
	        $stmt->bindParam(":city",$city);


	        $stmt->bindParam(":department",$department);
			
			   if($stmt->execute())






				
				{
				 		 echo"registered";


				
				}
				else
				{
					echo "Query could not execute !";
				}
			
			}
			else{
				
				echo "1"; //  not available
			}

				
				}
				else
				{
					echo "Query could not execute !";
				}
			
			}
			else{
				
				echo "1"; //  not available
			}
 				
					
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
		

	}
		




?>