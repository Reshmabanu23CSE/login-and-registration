<?php
	require 'dbconnect.php';
	if($_POST) {
		$errMsg = '';
		// Get data from FROM
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		if($fname == '')
			$errMsg = 'Enter your fname';
		if($lname == '')
			$errMsg = 'Enter lname';
		if($email == '')
			$errMsg = 'Enter email';
		if($password == '')
						$errMsg = 'Enter password';


			try {
				$stmt = $connect->prepare("SELECT * FROM users WHERE email=:email");
			$stmt->execute(array(":email"=>$email));
			$count = $stmt->rowCount();
			
			if($count==0){
				
			
				$stmt = $connect->prepare('INSERT INTO users (fname, lname, email, password) VALUES (:fname, :lname, :email, :password)');
				$stmt->execute(array(
					':fname' => $fname,
					':lname' => $lname,
					':email' => $email,
					':password' => $password
					));
					
				}
				else
				{
					echo"email already exsist";
				}
			}
			catch(PDOException $e) {
				echo $e->getMessage();
			}
		}
	
	
?>
