

<?php
	require 'dbconnect.php';
	if($_POST) {
		$errMsg = '';
		// Get data from FROM
		$username = $_POST['username'];
	
		$email = $_POST['email'];
		$contact = $_POST['contact'];
				$address = $_POST['address'];

		if($username == '')
			$errMsg = 'Enter your username';
		if($email == '')
			$errMsg = 'Enter email';
		if($contact == '')
			$errMsg = 'Enter contact';
		if($address == '')
						$errMsg = 'Enter address';


			try {
				$stmt = $connect->prepare('INSERT INTO details (username, email, contact, address) VALUES (:username, :email, :contact, :address)');
				$stmt->execute(array(
					':username' => $username,
					':email' => $email,
					':contact' => $contact,
					':address' => $address
					));

		 echo "New record created successfully";
		 
		 echo '<br><a href="index.html">click here to login</a><br>';

		
			}
			catch(PDOException $e) {
				echo $e->getMessage();
			}
		}
	
	
?>
